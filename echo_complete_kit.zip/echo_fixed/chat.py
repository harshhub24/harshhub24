"""
Interactive chat script for ECHO-50M (bug-fixed) with multi-turn memory.

Fixes over the original:
1. load_model() now passes weights_only=False to torch.load (checkpoints
   contain the ECHOConfig object; new PyTorch defaults would refuse to load).
2. State-dict keys are defensively cleaned (strips the "_orig_mod." prefix
   that torch.compile adds), so checkpoints saved during compiled training
   load cleanly.
3. Multi-turn memory: the conversation history ("User: ...\nResponse: ..."
   per turn) is appended to the context every turn and trimmed from the
   oldest side so the prompt always fits inside max_seq_len.
"""
import argparse
from typing import List, Tuple

import torch

from model import EchoTransformer
from tokenizer import ByteTokenizer


def load_model(checkpoint_path: str, device: str = "cuda"):
    """Load model from checkpoint."""
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    config = checkpoint["config"]
    model = EchoTransformer(config)
    # Defensive: strip any torch.compile prefix from saved keys
    state_dict = {k.replace("_orig_mod.", ""): v for k, v in checkpoint["model_state_dict"].items()}
    model.load_state_dict(state_dict)
    model.to(device)
    model.eval()
    return model, config


def build_prompt_ids(tokenizer, history: List[Tuple[str, str]], new_user: str,
                     max_ctx: int, max_new_tokens: int):
    """
    Render the full conversation in chat.py's training template:
        <bos>User: ...\nResponse: ...\nUser: ...\nResponse:
    and trim OLDEST turns until the prompt fits the context budget.
    """
    def render(hist):
        parts = [f"User: {u}\nResponse: {r}" for u, r in hist]
        parts.append(f"User: {new_user}\nResponse:")
        return "\n".join(parts)

    budget = max(16, max_ctx - max_new_tokens - 1)
    hist = list(history)
    ids = tokenizer.encode(render(hist), add_bos=True)
    while len(ids) > budget and hist:
        hist = hist[1:]  # drop the oldest turn
        ids = tokenizer.encode(render(hist), add_bos=True)
    return ids


def generate_response(
    model,
    tokenizer,
    prompt: str,
    history: List[Tuple[str, str]] = None,
    max_new_tokens: int = 200,
    temperature: float = 0.8,
    top_k: int = 50,
    top_p: float = 0.9,
    repetition_penalty: float = 1.1,
    device: str = "cuda",
) -> str:
    """Generate a response given the prompt plus conversation history."""
    history = history or []
    max_ctx = model.config.max_seq_len
    ids = build_prompt_ids(tokenizer, history, prompt, max_ctx, max_new_tokens)
    input_ids = torch.tensor([ids], dtype=torch.long).to(device)

    with torch.no_grad():
        output_ids = model.generate(
            input_ids=input_ids,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            eos_token_id=tokenizer.eos_token_id,
            pad_token_id=tokenizer.pad_token_id,
            use_cache=True,
        )

    # Decode only the newly generated part (skip prompt)
    prompt_len = input_ids.shape[1]
    response_ids = output_ids[0, prompt_len:]
    response = tokenizer.decode(response_ids, skip_special_tokens=True)
    return response.strip()


def interactive_chat(
    checkpoint_path: str,
    device: str = "cuda",
    max_new_tokens: int = 200,
    temperature: float = 0.8,
    top_k: int = 50,
    top_p: float = 0.9,
    repetition_penalty: float = 1.1,
    remember_turns: int = 10,
):
    """Run an interactive chat loop with multi-turn memory."""
    print("Loading ECHO-50M model...")
    model, config = load_model(checkpoint_path, device)
    tokenizer = ByteTokenizer()
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Model loaded: {n_params/1e6:.2f}M parameters (ctx {config.max_seq_len})")
    print("Interactive chat started. Type 'exit' or 'quit' to stop, '/reset' to clear memory.\n")

    history: List[Tuple[str, str]] = []

    while True:
        try:
            user_input = input("User: ")
        except (KeyboardInterrupt, EOFError):
            break
        if user_input.lower() in ["exit", "quit"]:
            break
        if user_input.lower() == "/reset":
            history = []
            print("(memory cleared)\n")
            continue
        if not user_input.strip():
            continue

        response = generate_response(
            model,
            tokenizer,
            user_input,
            history=history[-remember_turns:] if remember_turns else [],
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            device=device,
        )
        history.append((user_input, response))
        print(f"Response: {response}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, required=True, help="Path to checkpoint file")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--max_new_tokens", type=int, default=200)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--top_k", type=int, default=50)
    parser.add_argument("--top_p", type=float, default=0.9)
    parser.add_argument("--repetition_penalty", type=float, default=1.1)
    parser.add_argument("--remember_turns", type=int, default=10,
                        help="How many past turns to keep in the context")
    args = parser.parse_args()

    interactive_chat(
        checkpoint_path=args.checkpoint,
        device=args.device,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
        top_k=args.top_k,
        top_p=args.top_p,
        repetition_penalty=args.repetition_penalty,
        remember_turns=args.remember_turns,
    )
