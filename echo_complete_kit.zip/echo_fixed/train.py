"""
Training script for ECHO-50M (bug-fixed) with mixed precision, checkpointing,
resume, and SFT support for the {prompt, response} JSON datasets.

Fixes over the original:
1. torch.load() now uses weights_only=False explicitly (checkpoints contain
   the ECHOConfig object + optimizer state; new PyTorch versions refuse to
   unpickle custom objects with the default safe loader).
2. torch.compile() prefixes state-dict keys with "_orig_mod." which made
   saved checkpoints impossible to load in chat.py. Keys are now stripped
   before saving (and defensively on load).
3. Resume was broken: the LR scheduler restarted from step 0 and mid-epoch
   batches were re-trained. The scheduler state and batch position inside the
   epoch are now saved and restored.
4. TextDataset stored the whole corpus as a Python list of ints (~28 bytes
   per token). It now uses a compact numpy int16 buffer (~2 bytes per token).
5. New InstructDataset: trains on {prompt, response} pairs with the chat
   template used by chat.py, adds <bos>/<eos>, and masks prompt tokens with
   -100 so the loss is only computed on the response.
6. Leftover gradients are flushed at the end of each epoch, loss averaging is
   computed from the real number of optimizer steps, and tensorboard is now
   an optional import (the hard import crashed machines without it).
"""
import os
import json
import time
import math
import random
import argparse
from typing import Optional, List, Dict, Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.amp import autocast, GradScaler

try:  # optional dependency, must not crash training
    from torch.utils.tensorboard import SummaryWriter
    _TB_AVAILABLE = True
except ImportError:
    SummaryWriter = None
    _TB_AVAILABLE = False

from config import ECHOConfig
from tokenizer import ByteTokenizer
from model import EchoTransformer


# ---------- Datasets ----------
class TextDataset(Dataset):
    """Plain LM dataset over raw text. Compact int16 storage (FIX #4)."""

    def __init__(self, text: str, tokenizer: ByteTokenizer, seq_len: int, stride: int = None):
        self.tokenizer = tokenizer
        self.seq_len = seq_len
        ids = np.array(tokenizer.encode(text), dtype=np.int16)  # compact buffer
        print(f"Text length: {len(text)} chars, {len(ids)} tokens")
        stride = stride or seq_len  # non-overlapping by default
        self.chunks: List[np.ndarray] = []
        for start in range(0, max(1, len(ids) - seq_len + 1), stride):
            chunk = ids[start:start + seq_len]
            if len(chunk) < seq_len:  # pad only the final chunk
                chunk = np.concatenate(
                    [chunk, np.full(seq_len - len(chunk), tokenizer.pad_token_id, dtype=np.int16)]
                )
            self.chunks.append(chunk)
        if not self.chunks:  # corpus shorter than one sequence
            chunk = np.full(seq_len, tokenizer.pad_token_id, dtype=np.int16)
            chunk[: len(ids)] = ids
            self.chunks.append(chunk)

    def __len__(self):
        return len(self.chunks)

    def __getitem__(self, idx):
        chunk = torch.from_numpy(self.chunks[idx].astype(np.int64))
        labels = chunk.clone()
        attention_mask = (chunk != self.tokenizer.pad_token_id).long()
        return {"input_ids": chunk, "labels": labels, "attention_mask": attention_mask}


class InstructDataset(Dataset):
    """SFT dataset for {prompt, response} pairs (FIX #5).

    Formats each pair exactly like chat.py does:
        <bos> User: {prompt}\nResponse: {response}<eos>
    Loss is computed ONLY on the response tokens (+ <eos>): prompt tokens are
    masked with -100 so the model learns to answer, not to repeat the prompt.
    """

    def __init__(self, pairs: List[Dict[str, str]], tokenizer: ByteTokenizer, seq_len: int):
        self.tokenizer = tokenizer
        self.seq_len = seq_len
        # Drop samples whose PROMPT alone does not fit the context (otherwise the
        # label tensor could end up LONGER than the input tensor).
        kept = []
        for pr in pairs:
            n_prompt = len(tokenizer.encode(f"User: {pr['prompt']}\nResponse:", add_bos=True))
            if n_prompt < seq_len - 1:  # need room for at least one response token
                kept.append(pr)
        dropped = len(pairs) - len(kept)
        if dropped:
            print(f"InstructDataset: dropped {dropped}/{len(pairs)} pairs "
                  f"(prompt longer than seq_len={seq_len})")
        self.pairs = kept

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        p = self.pairs[idx]["prompt"]
        r = self.pairs[idx]["response"]

        prompt_ids = self.tokenizer.encode(f"User: {p}\nResponse:", add_bos=True)
        full_ids = self.tokenizer.encode(f"User: {p}\nResponse: {r}", add_bos=True, add_eos=True)

        # Truncate long samples (keep the start; always keep an <eos> at the end)
        if len(full_ids) > self.seq_len:
            full_ids = full_ids[: self.seq_len - 1] + [self.tokenizer.eos_token_id]

        # Defensive clamp: always supervise at least the final <eos>
        n_prompt = min(len(prompt_ids), len(full_ids) - 1)
        labels = [-100] * n_prompt + full_ids[n_prompt:]

        # Right-pad to seq_len
        pad = max(0, self.seq_len - len(full_ids))
        input_ids = full_ids + [self.tokenizer.pad_token_id] * pad
        labels = labels + [-100] * pad
        attention_mask = [1] * len(full_ids) + [0] * pad

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
        }


def load_pairs_from_json(path: str, max_samples: Optional[int] = None) -> List[Dict[str, str]]:
    """Load a JSON file containing a list of {prompt, response} objects."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert isinstance(data, list) and "prompt" in data[0], (
        f"{path}: expected a JSON list of objects with 'prompt' and 'response' keys"
    )
    if max_samples:
        data = data[:max_samples]
    print(f"Loaded {len(data)} pairs from {path}")
    return data


def collate_fn(batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
    """Dynamic padding collate function."""
    max_len = max(x["input_ids"].size(0) for x in batch)
    batch_size = len(batch)

    input_ids = torch.full((batch_size, max_len), 0, dtype=torch.long)      # pad token id = 0
    labels = torch.full((batch_size, max_len), -100, dtype=torch.long)      # ignore index for loss
    attention_mask = torch.zeros((batch_size, max_len), dtype=torch.long)

    for i, item in enumerate(batch):
        seq_len = item["input_ids"].size(0)
        input_ids[i, :seq_len] = item["input_ids"]
        labels[i, :seq_len] = item["labels"]
        attention_mask[i, :seq_len] = item["attention_mask"]

    # Replace padding labels with -100 so they are ignored in loss
    labels[attention_mask == 0] = -100
    return {"input_ids": input_ids, "labels": labels, "attention_mask": attention_mask}


# ---------- Checkpointing ----------
def _clean_state_dict(state_dict: dict) -> dict:
    """Strip the 'torch.compile' _orig_mod. prefix (FIX #2)."""
    return {k.replace("_orig_mod.", ""): v for k, v in state_dict.items()}


def save_checkpoint(
    model: nn.Module,
    optimizer: optim.Optimizer,
    scaler: GradScaler,
    scheduler,
    epoch: int,
    global_step: int,
    batches_in_epoch: int,
    loss: float,
    config: ECHOConfig,
    save_path: str,
):
    """Save full training state (model / optimizer / scaler / scheduler / position)."""
    checkpoint = {
        "model_state_dict": _clean_state_dict(model.state_dict()),
        "optimizer_state_dict": optimizer.state_dict(),
        "scaler_state_dict": scaler.state_dict(),
        "scheduler_state_dict": scheduler.state_dict(),      # FIX #3
        "epoch": epoch,
        "global_step": global_step,
        "batches_in_epoch": batches_in_epoch,                # FIX #3
        "loss": loss,
        "config": config,
    }
    torch.save(checkpoint, save_path)
    print(f"Checkpoint saved to {save_path}")


def load_checkpoint(
    model: nn.Module,
    optimizer: optim.Optimizer,
    scaler: GradScaler,
    scheduler,
    checkpoint_path: str,
):
    """Load checkpoint and return epoch, global_step, batches_in_epoch, loss."""
    if not os.path.exists(checkpoint_path):
        print(f"No checkpoint found at {checkpoint_path}, starting from scratch.")
        return 0, 0, 0, float("inf")
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)  # FIX #1
    model.load_state_dict(_clean_state_dict(checkpoint["model_state_dict"]))          # FIX #2
    optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    scaler.load_state_dict(checkpoint["scaler_state_dict"])
    if "scheduler_state_dict" in checkpoint:
        scheduler.load_state_dict(checkpoint["scheduler_state_dict"])                 # FIX #3
    epoch = checkpoint.get("epoch", 0)
    step = checkpoint.get("global_step", 0)
    batches_in_epoch = checkpoint.get("batches_in_epoch", 0)
    loss = checkpoint.get("loss", float("inf"))
    print(f"Resumed from checkpoint: epoch={epoch}, step={step}, loss={loss:.4f}")
    return epoch, step, batches_in_epoch, loss


def load_pretrained_weights(model: nn.Module, ckpt_path: str) -> None:
    """Load ONLY model weights from a checkpoint (fresh optimizer/scheduler).

    Used to transfer a pretrained model into SFT training without touching
    optimizer/scheduler/epoch state (unlike load_checkpoint which resumes
    everything).
    """
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    sd = {k.replace("_orig_mod.", ""): v for k, v in ck["model_state_dict"].items()}
    missing, unexpected = model.load_state_dict(sd, strict=False)
    print(f"Initialized weights from {ckpt_path} "
          f"(missing={len(missing)}, unexpected={len(unexpected)})")


# ---------- Optimizer ----------
def create_optimizer(model: nn.Module, config: ECHOConfig) -> optim.Optimizer:
    """AdamW optimizer with weight decay."""
    decay_params = []
    no_decay_params = []
    for name, param in model.named_parameters():
        if param.requires_grad:
            if "bias" in name or "norm" in name or "token_embedding" in name:
                no_decay_params.append(param)
            else:
                decay_params.append(param)
    param_groups = [
        {"params": decay_params, "weight_decay": config.weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]
    return optim.AdamW(param_groups, lr=config.learning_rate, betas=(0.9, 0.95))


# ---------- Training loop ----------
def train(
    config: ECHOConfig,
    train_text: Optional[str] = None,
    pairs: Optional[List[Dict[str, str]]] = None,
    num_workers: int = 0,
    tensorboard: bool = False,
    init_from: Optional[str] = None,
):
    """Main training loop. Provide EITHER train_text (LM mode) OR pairs (SFT mode)."""
    assert (train_text is None) != (pairs is None), "Pass either train_text or pairs"
    device = torch.device(config.device if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True

    tokenizer = ByteTokenizer()

    # Dataset and DataLoader
    if pairs is not None:
        train_dataset = InstructDataset(pairs, tokenizer, seq_len=config.max_seq_len)
        print(f"SFT mode: {len(train_dataset)} instruction pairs")
    else:
        train_dataset = TextDataset(train_text, tokenizer, seq_len=config.max_seq_len)
        print(f"LM mode: {len(train_dataset)} chunks")
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
        drop_last=False,
    )

    # Model
    model = EchoTransformer(config).to(device)
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Model parameters: {n_params/1e6:.2f}M")

    # Pretrained-weight initialization (pretrain -> SFT transfer). Must run
    # BEFORE resume logic, so an explicit resume still overrides it.
    if init_from:
        load_pretrained_weights(model, init_from)

    optimizer = create_optimizer(model, config)
    scaler = GradScaler(enabled=(device.type == "cuda"))

    # LR scheduler: cosine with warmup, counted in OPTIMIZER steps
    steps_per_epoch = math.ceil(len(train_loader) / config.grad_accum_steps)
    total_steps = max(1, steps_per_epoch * config.max_epochs)
    warmup_steps = min(config.warmup_steps, total_steps - 1) if total_steps > 1 else 0

    def lr_lambda(current_step):
        if current_step < warmup_steps:
            return float(current_step) / float(max(1, warmup_steps))
        progress = float(current_step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

    scheduler = optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    # Resume (before torch.compile, so state dicts line up cleanly)
    os.makedirs(config.checkpoint_dir, exist_ok=True)
    checkpoint_path = os.path.join(config.checkpoint_dir, "latest_checkpoint.pt")
    if config.resume:
        start_epoch, global_step, start_batch, best_loss = load_checkpoint(
            model, optimizer, scaler, scheduler, checkpoint_path
        )
    else:
        start_epoch, global_step, start_batch, best_loss = 0, 0, 0, float("inf")

    # torch.compile AFTER checkpoint loading (PyTorch 2.0+)
    if hasattr(torch, "compile") and device.type == "cuda" and not os.environ.get("ECHO_NO_COMPILE"):
        print("Using torch.compile...")
        model = torch.compile(model)

    writer = None
    if tensorboard and _TB_AVAILABLE:
        writer = SummaryWriter(log_dir="runs/echo50m")

    # Training loop
    model.train()
    for epoch in range(start_epoch, config.max_epochs):
        epoch_loss = 0.0
        opt_steps_this_epoch = 0
        batches_done = start_batch if epoch == start_epoch else 0
        epoch_start_time = time.time()

        micro_loss_sum = 0.0  # sum of unnormalized micro-batch losses
        pending = 0           # accumulated micro-batches not yet stepped

        for batch_idx, batch in enumerate(train_loader):
            if batch_idx < batches_done:  # FIX #3: skip already-trained batches
                continue

            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            attention_mask = batch["attention_mask"].to(device)

            with autocast(device_type=device.type, dtype=torch.float16, enabled=(device.type == "cuda")):
                outputs = model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels,
                )
                loss = outputs["loss"] / config.grad_accum_steps

            scaler.scale(loss).backward()
            micro_loss_sum += loss.item() * config.grad_accum_steps
            pending += 1

            if pending == config.grad_accum_steps:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
                scheduler.step()
                global_step += 1
                pending = 0

                current_loss = micro_loss_sum / config.grad_accum_steps
                epoch_loss += current_loss
                opt_steps_this_epoch += 1
                micro_loss_sum = 0.0
                if global_step % 50 == 0:
                    lr = optimizer.param_groups[0]["lr"]
                    print(f"Epoch {epoch+1}, Step {global_step}, Loss: {current_loss:.4f}, LR: {lr:.6f}")
                    if writer:
                        writer.add_scalar("train/loss", current_loss, global_step)
                        writer.add_scalar("train/lr", lr, global_step)

                if config.save_every and global_step % config.save_every == 0:
                    save_checkpoint(
                        model, optimizer, scaler, scheduler,
                        epoch, global_step, batch_idx + 1, current_loss,
                        config, checkpoint_path,
                    )

        # FIX #6: flush leftover gradients at the end of the epoch
        if pending > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
            scheduler.step()
            global_step += 1
            epoch_loss += micro_loss_sum / pending
            opt_steps_this_epoch += 1

        avg_loss = epoch_loss / max(1, opt_steps_this_epoch)   # FIX #6: true step count
        print(
            f"Epoch {epoch+1} finished. Average loss: {avg_loss:.4f}, "
            f"Time: {time.time()-epoch_start_time:.2f}s"
        )
        if writer:
            writer.add_scalar("train/epoch_loss", avg_loss, epoch)

        # Save at end of epoch (position reset -> next epoch starts clean)
        save_checkpoint(
            model, optimizer, scaler, scheduler,
            epoch + 1, global_step, 0, avg_loss,
            config, checkpoint_path,
        )

    print("Training completed.")


# ---------- Main ----------
def main():
    parser = argparse.ArgumentParser(description="Train ECHO-50M (LM or SFT mode)")
    parser.add_argument("--data", type=str, nargs="*", default=None,
                        help="Path(s) to JSON dataset(s) with {prompt, response} pairs -> SFT mode")
    parser.add_argument("--lm_text", type=str, default=None,
                        help="Path to a raw text file -> LM pretraining mode (world knowledge)")
    parser.add_argument("--init_from", type=str, default=None,
                        help="Checkpoint to load model weights from (e.g. pretrained model for SFT)")
    parser.add_argument("--max_samples", type=int, default=None,
                        help="Cap pairs per dataset file (useful for quick tests)")
    parser.add_argument("--epochs", type=int, default=None, help="Override max_epochs")
    parser.add_argument("--lr", type=float, default=None, help="Override learning_rate")
    parser.add_argument("--batch_size", type=int, default=None, help="Override batch_size")
    parser.add_argument("--grad_accum", type=int, default=None, help="Override grad_accum_steps")
    parser.add_argument("--seq_len", type=int, default=None, help="Override max_seq_len")
    parser.add_argument("--n_layer", type=int, default=None, help="Override model depth")
    parser.add_argument("--n_embd", type=int, default=None, help="Override embedding width")
    parser.add_argument("--n_head", type=int, default=None, help="Override attention heads")
    parser.add_argument("--save_every", type=int, default=None, help="Override save_every")
    parser.add_argument("--checkpoint_dir", type=str, default=None, help="Override checkpoint_dir")
    parser.add_argument("--workers", type=int, default=0, help="DataLoader workers")
    parser.add_argument("--no_resume", action="store_true", help="Do not resume from checkpoint")
    parser.add_argument("--tensorboard", action="store_true", help="Log to TensorBoard")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    config = ECHOConfig()
    if args.epochs is not None:
        config.max_epochs = args.epochs
    if args.lr is not None:
        config.learning_rate = args.lr
    if args.batch_size is not None:
        config.batch_size = args.batch_size
    if args.grad_accum is not None:
        config.grad_accum_steps = args.grad_accum
    if args.seq_len is not None:
        config.max_seq_len = args.seq_len
    if args.n_layer is not None:
        config.n_layer = args.n_layer
    if args.n_embd is not None:
        config.n_embd = args.n_embd
    if args.n_head is not None:
        config.n_head = args.n_head
    if args.save_every is not None:
        config.save_every = args.save_every
    if args.checkpoint_dir is not None:
        config.checkpoint_dir = args.checkpoint_dir
    # Re-derive head_dim and re-validate after any architecture overrides
    config.head_dim = config.n_embd // config.n_head
    config.__post_init__()
    config.resume = not args.no_resume

    if args.data:
        pairs = []
        for path in args.data:
            pairs.extend(load_pairs_from_json(path, args.max_samples))
        print(f"Total SFT pairs: {len(pairs)}")
        train(config, pairs=pairs, num_workers=args.workers,
              tensorboard=args.tensorboard, init_from=args.init_from)
    elif args.lm_text:
        with open(args.lm_text, "r", encoding="utf-8") as f:
            text = f.read()
        print(f"LM pretraining on {args.lm_text}: {len(text)/1e6:.1f}MB text")
        train(config, train_text=text, num_workers=args.workers,
              tensorboard=args.tensorboard)
    else:
        # LM demo on dummy text (use --data to train on real datasets)
        sample_text = (
            'This is a sample text for training ECHO-50M. It contains English, some '
            'Hinglish words like "namaste", "kaise ho", and code snippets: '
            'def hello(): print("Hello World")\n'
        )
        train(config, train_text=sample_text * 1000, num_workers=args.workers,
              tensorboard=args.tensorboard)


if __name__ == "__main__":
    main()
