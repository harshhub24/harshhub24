"""
ECHO-50M Decoder-Only Transformer (Llama-3 / Gemma style) - bug-fixed version.

Fixes over the original:
1.  Training was NOT causal: when an attention_mask was passed, SDPA was called
    with is_causal=False and only the padding mask, so the model could see
    future tokens (verified: changing a future token changed past logits).
    Now a proper causal+padding combined mask is built whenever a padding mask
    is given, and is_causal=True is used when there is no padding.
2.  KV-cache generation crashed (RoPE returned cos/sin for the full KV length
    while q had only 1 new token). RoPE is now computed from absolute token
    positions, applied BEFORE concatenation with the cached keys, and the
    cache stores already-rotated keys. Cached and uncached generation now
    produce identical results.
3.  generate() re-fed the WHOLE sequence every step while using the KV cache
    (corrupting positions and duplicating cache). Now only the newest token is
    fed after the first forward pass.
4.  hidden states are only collected when explicitly requested (less memory),
    and cross_entropy uses ignore_index=-100 explicitly for SFT label masking.
"""
import math
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import ECHOConfig


class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization."""

    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def _norm(self, x: torch.Tensor) -> torch.Tensor:
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.weight * self._norm(x.float()).type_as(x)


class RotaryEmbedding(nn.Module):
    """Rotary Position Embedding (RoPE).

    Computes cos/sin on the fly for arbitrary absolute positions, which makes
    KV-cache decoding trivially correct (FIX #2).
    """

    def __init__(self, dim: int, theta: float = 10000.0):
        super().__init__()
        self.dim = dim
        inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(self, positions: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        # positions: (L,) integer tensor of absolute token positions
        freqs = positions[:, None].float() * self.inv_freq[None, :]   # (L, dim/2)
        emb = torch.cat((freqs, freqs), dim=-1)                       # (L, dim)
        return emb.cos(), emb.sin()


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Rotate half the hidden dims of the input."""
    x1, x2 = x[..., : x.shape[-1] // 2], x[..., x.shape[-1] // 2:]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin):
    """Apply RoPE to query and key tensors."""
    # q, k: (batch, num_heads, seq_len, head_dim)
    # cos, sin: (seq_len, head_dim)
    cos = cos.unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, head_dim)
    sin = sin.unsqueeze(0).unsqueeze(0)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class Attention(nn.Module):
    """Causal self-attention with RoPE and native scaled_dot_product_attention."""

    def __init__(self, config: ECHOConfig):
        super().__init__()
        self.n_embd = config.n_embd
        self.n_head = config.n_head
        self.head_dim = config.head_dim
        self.dropout = config.dropout

        # Linear projections (no bias)
        self.wq = nn.Linear(self.n_embd, self.n_embd, bias=config.bias)
        self.wk = nn.Linear(self.n_embd, self.n_embd, bias=config.bias)
        self.wv = nn.Linear(self.n_embd, self.n_embd, bias=config.bias)
        self.wo = nn.Linear(self.n_embd, self.n_embd, bias=config.bias)

        self.rotary = RotaryEmbedding(self.head_dim, theta=config.rope_theta)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_kv: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        """
        x: (batch, cur_len, n_embd)
        mask: optional padding mask of shape (batch, kv_len) with 1 = valid,
              0 = padding (combined with the causal mask inside this function).
        past_kv: cached (k, v) of shape (batch, n_head, past_len, head_dim);
                 keys are stored ALREADY RoPE-rotated.
        """
        batch, cur_len, _ = x.shape

        # Project to q, k, v
        q = self.wq(x)
        k = self.wk(x)
        v = self.wv(x)

        # Reshape to (batch, num_heads, seq_len, head_dim)
        q = q.view(batch, cur_len, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(batch, cur_len, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(batch, cur_len, self.n_head, self.head_dim).transpose(1, 2)

        past_len = past_kv[0].shape[2] if (use_cache and past_kv is not None) else 0
        kv_len = past_len + cur_len

        # RoPE on the NEW tokens only, at their absolute positions (FIX #2).
        # Applied BEFORE concatenation with cached keys (they are already rotated).
        positions = torch.arange(past_len, kv_len, device=x.device)
        cos, sin = self.rotary(positions)
        q, k = apply_rotary_pos_emb(q, k, cos, sin)

        # Concatenate cached keys/values (FIX #2: after rotating new k)
        if use_cache and past_kv is not None:
            past_k, past_v = past_kv
            k = torch.cat([past_k, k], dim=2)
            v = torch.cat([past_v, v], dim=2)

        # --- Mask handling (FIX #1: keep attention causal) ---
        if cur_len == 1:
            # Single-token decode step: the only query is the newest position,
            # so it may attend to all cached keys. No mask needed.
            attn_mask, is_causal = None, False
        elif mask is None:
            # Full-sequence forward without padding: plain causal attention.
            attn_mask, is_causal = None, True
        else:
            # Forward WITH padding: combine causal + padding into one additive mask.
            m = mask[:, -kv_len:] if mask.shape[1] > kv_len else mask  # safety
            causal = torch.tril(
                torch.ones(cur_len, kv_len, dtype=torch.bool, device=x.device)
            )
            keep = causal.unsqueeze(0) & m.to(torch.bool)[:, None, :]  # (b, cur, kv)
            attn_mask = torch.zeros(batch, 1, cur_len, kv_len, device=x.device)
            attn_mask = attn_mask.masked_fill(~keep.unsqueeze(1), float("-inf"))
            is_causal = False

        attn_output = F.scaled_dot_product_attention(
            q, k, v,
            attn_mask=attn_mask,
            dropout_p=self.dropout if self.training else 0.0,
            is_causal=is_causal,
        )

        # Reshape back
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch, cur_len, self.n_embd)
        out = self.wo(attn_output)

        if use_cache:
            return out, (k, v)  # keys are RoPE-rotated at their absolute positions
        return out, None


class SwiGLU(nn.Module):
    """SwiGLU MLP: silu(gate(x)) * up(x), then down projection."""

    def __init__(self, config: ECHOConfig):
        super().__init__()
        self.gate_proj = nn.Linear(config.n_embd, config.intermediate_size, bias=config.bias)
        self.up_proj = nn.Linear(config.n_embd, config.intermediate_size, bias=config.bias)
        self.down_proj = nn.Linear(config.intermediate_size, config.n_embd, bias=config.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class TransformerBlock(nn.Module):
    """Pre-norm transformer block."""

    def __init__(self, config: ECHOConfig):
        super().__init__()
        self.attn_norm = RMSNorm(config.n_embd)
        self.attn = Attention(config)
        self.mlp_norm = RMSNorm(config.n_embd)
        self.mlp = SwiGLU(config)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_kv: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        # Attention residual
        attn_out, new_kv = self.attn(self.attn_norm(x), mask=mask, use_cache=use_cache, past_kv=past_kv)
        x = x + attn_out
        # MLP residual
        x = x + self.mlp(self.mlp_norm(x))
        return x, new_kv


class EchoTransformer(nn.Module):
    """Complete ECHO-50M model."""

    def __init__(self, config: ECHOConfig):
        super().__init__()
        self.config = config
        self.token_embedding = nn.Embedding(config.vocab_size, config.n_embd)
        self.layers = nn.ModuleList([TransformerBlock(config) for _ in range(config.n_layer)])
        self.final_norm = RMSNorm(config.n_embd)
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)

        # Tie weights (optional but common)
        self.token_embedding.weight = self.lm_head.weight

        # Initialize weights
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        use_cache: bool = False,
        past_key_values: Optional[list] = None,
        output_hidden_states: bool = False,
    ) -> dict:
        batch, seq_len = input_ids.shape
        x = self.token_embedding(input_ids)

        # Shortcut: if there is no padding at all, pure causal attention is enough.
        if attention_mask is not None and bool((attention_mask == 1).all()):
            attention_mask = None

        if use_cache and past_key_values is None:
            past_key_values = [None] * len(self.layers)

        hidden_states = [] if output_hidden_states else None
        present_key_values = [] if use_cache else None

        for i, layer in enumerate(self.layers):
            past_kv = past_key_values[i] if past_key_values is not None else None
            x, new_kv = layer(
                x,
                mask=attention_mask,       # (batch, seq_len) padding mask or None
                use_cache=use_cache,
                past_kv=past_kv,
            )
            if output_hidden_states:
                hidden_states.append(x)
            if use_cache:
                present_key_values.append(new_kv)

        x = self.final_norm(x)
        logits = self.lm_head(x)

        loss = None
        if labels is not None:
            # Shift so that tokens < n predict n.
            # Positions marked -100 (e.g. prompt tokens in SFT) are ignored.
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                ignore_index=-100,
            )

        return {
            "logits": logits,
            "loss": loss,
            "hidden_states": hidden_states,
            "present_key_values": present_key_values,
        }

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 100,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        repetition_penalty: float = 1.0,
        eos_token_id: int = 2,
        pad_token_id: int = 0,
        use_cache: bool = True,
    ) -> torch.Tensor:
        """Autoregressive generation with caching.

        FIX #3: after the first forward pass, only the newest token is fed to
        the model (the KV cache holds the rest), so positions and cache stay
        correct. Results are identical to uncached generation.
        """
        self.eval()
        batch_size = input_ids.shape[0]
        past_key_values = None
        generated = input_ids
        cur_ids = input_ids

        for _ in range(max_new_tokens):
            # Forward pass (full prompt first, then only the newest token)
            outputs = self.forward(
                cur_ids,
                use_cache=use_cache,
                past_key_values=past_key_values,
            )
            if use_cache:
                past_key_values = outputs["present_key_values"]
            logits = outputs["logits"][:, -1, :]  # (batch, vocab_size)

            # Apply repetition penalty
            if repetition_penalty != 1.0:
                for i in range(batch_size):
                    for token_id in set(generated[i].tolist()):
                        if logits[i, token_id] > 0:
                            logits[i, token_id] /= repetition_penalty
                        else:
                            logits[i, token_id] *= repetition_penalty

            # Temperature
            if temperature != 1.0:
                logits = logits / temperature

            # Top-K
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, -1:]] = float("-inf")

            # Top-P (nucleus)
            if top_p is not None:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                # Remove tokens with cumulative probability above the threshold
                sorted_indices_to_remove = cumulative_probs > top_p
                # Shift right to keep the first token above the threshold
                sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                sorted_indices_to_remove[..., 0] = 0
                for b in range(batch_size):
                    indices_to_remove = sorted_indices[b][sorted_indices_to_remove[b]]
                    logits[b, indices_to_remove] = float("-inf")

            # Sample next token
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)  # (batch, 1)

            # Append to generated
            generated = torch.cat([generated, next_token], dim=1)

            # FIX #3: feed only the new token on the next step when caching
            cur_ids = next_token if use_cache else generated

            # Stop if all sequences hit EOS
            if (next_token == eos_token_id).all():
                break

        return generated
