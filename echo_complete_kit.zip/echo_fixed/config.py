"""
ECHO-50M Configuration (bug-fixed).

Fixes:
1. num_parameters() imported EchoTransformer but never imported it -> NameError
   crash. Now uses a proper lazy import.
2. intermediate_size had a hardcoded override in __post_init__ that silently
   discarded any custom value. Now None means "auto compute 8/3 * n_embd",
   and an explicit value is respected.
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class ECHOConfig:
    # Architecture
    vocab_size: int = 260                 # 256 bytes + 4 special tokens
    n_layer: int = 10
    n_embd: int = 640
    n_head: int = 10
    head_dim: int = 64                    # n_embd // n_head
    intermediate_size: Optional[int] = None   # None -> auto: 8/3 * n_embd
    max_seq_len: int = 1024               # maximum sequence length
    dropout: float = 0.0                  # no dropout for modern LLMs
    bias: bool = False                    # no bias in linear layers

    # RoPE
    rope_theta: float = 10000.0

    # Training
    learning_rate: float = 3e-4
    weight_decay: float = 0.1
    batch_size: int = 8
    grad_accum_steps: int = 4
    max_epochs: int = 1
    warmup_steps: int = 100
    dtype: str = "float32"                # base dtype for model params
    device: str = "cuda"

    # Checkpointing
    checkpoint_dir: str = "checkpoints"
    save_every: int = 500                 # save every N optimizer steps
    resume: bool = True

    # Generation
    use_cache: bool = True                # KV cache for inference

    def __post_init__(self):
        assert self.n_embd % self.n_head == 0, "n_embd must be divisible by n_head"
        assert self.head_dim * self.n_head == self.n_embd
        # Only auto-compute when no explicit value was given (FIX #2)
        if self.intermediate_size is None:
            self.intermediate_size = int(8 / 3 * self.n_embd)

    def num_parameters(self) -> int:
        """Total number of trainable parameters (lazy import avoids circular import)."""
        from model import EchoTransformer  # FIX #1: this import was missing -> NameError
        model = EchoTransformer(self)
        return sum(p.numel() for p in model.parameters() if p.requires_grad)

    def num_parameters_millions(self) -> float:
        return self.num_parameters() / 1e6
