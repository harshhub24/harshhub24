"""
Byte-level Tokenizer for ECHO-50M (bug-fixed).
Vocab size: 260 = 256 raw bytes + 4 special tokens.

Fixes:
1. decode() referenced torch.Tensor but torch was never imported -> NameError
   crash whenever a tensor was passed (chat.py always does this).
   torch is now imported at module level.
"""
import torch
from typing import List, Union


class ByteTokenizer:
    def __init__(self):
        self.pad_token = "<pad>"
        self.bos_token = "<bos>"
        self.eos_token = "<eos>"
        self.unk_token = "<unk>"

        self.special_tokens = [self.pad_token, self.bos_token, self.eos_token, self.unk_token]
        self.pad_token_id = 0
        self.bos_token_id = 1
        self.eos_token_id = 2
        self.unk_token_id = 3

        self.byte_to_id = {i: i + len(self.special_tokens) for i in range(256)}
        self.id_to_byte = {v: k for k, v in self.byte_to_id.items()}

        self.vocab_size = 256 + len(self.special_tokens)

    def encode(
        self,
        text: str,
        add_bos: bool = False,
        add_eos: bool = False,
        return_tensors: str = None,
    ) -> Union[List[int], "torch.Tensor"]:
        """Convert text to list of token IDs (or tensor)."""
        ids: List[int] = []
        if add_bos:
            ids.append(self.bos_token_id)
        # Encode each character as its UTF-8 byte sequence
        for ch in text:
            for b in ch.encode("utf-8"):
                ids.append(self.byte_to_id[b])
        if add_eos:
            ids.append(self.eos_token_id)

        if return_tensors == "pt":
            return torch.tensor(ids, dtype=torch.long)
        return ids

    def decode(self, ids: Union[List[int], "torch.Tensor"], skip_special_tokens: bool = True) -> str:
        """Convert token IDs back to string."""
        if isinstance(ids, torch.Tensor):  # FIX #1: torch is now imported
            ids = ids.tolist()
        bytes_list = []
        for token_id in ids:
            if token_id in self.id_to_byte:
                bytes_list.append(self.id_to_byte[token_id])
            elif token_id in (self.pad_token_id, self.bos_token_id, self.eos_token_id, self.unk_token_id):
                if not skip_special_tokens:
                    bytes_list.extend(self.special_tokens[token_id].encode("utf-8"))
            else:
                # unknown token: replace with nothing or ?
                if not skip_special_tokens:
                    bytes_list.extend(b"?")
        return bytes(bytes_list).decode("utf-8", errors="replace")

    def batch_decode(self, batch_ids: List[List[int]], skip_special_tokens: bool = True) -> List[str]:
        return [self.decode(ids, skip_special_tokens) for ids in batch_ids]
