"""
ECHO pretraining corpus builder - RUN THIS ON COLAB.

Downloads a knowledge-rich text mix via HuggingFace `datasets` (streaming),
cleans it, and writes one big pretrain_text.txt for:
    python train.py --lm_text pretrain_text.txt --epochs 1 --lr 3e-4 ...

Default mix (~500M byte-tokens, byte-level tokenizer = 1 byte = 1 token):
  - Simple English Wikipedia : world knowledge in easy English (Roman script)
  - TinyStories              : narrative coherence training
  - English Wikipedia subset : deeper world knowledge
  - (optional) local Hinglish corpus file, e.g. L3Cube HingCorpus download
    -> pass with --hinglish_file hinglish.txt --hinglish_m 50

Usage (Colab):
    !pip -q install datasets
    !python prep_data.py --wiki_simple_m 200 --stories_m 100 --wiki_en_m 150 \
        --hinglish_file hinglish.txt --hinglish_m 50 --out pretrain_text.txt

Quick pipeline test WITHOUT downloading anything:
    python prep_data.py --tiny_demo --out demo.txt
"""
import argparse
import hashlib
import os
import random
import re

SEEN = set()


def clean(text: str):
    """Basic cleanup for web/wiki text. Returns None for junk docs."""
    t = text.strip()
    t = re.sub(r"\r", "", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    t = re.sub(r"[ \t]{2,}", " ", t)
    if len(t) < 250:          # too short to be useful
        return None
    printable = sum(1 for c in t if c.isprintable() or c == "\n")
    if printable / len(t) < 0.95:   # junk characters
        return None
    return t


class Corpus:
    """Collects cleaned, deduped docs under a character (byte-token) budget."""

    def __init__(self):
        self.docs = []
        self.used = 0
        self.stats = {}

    def harvest(self, iterable, budget_chars: int, label: str, log_every=200,
                max_examined=3_000_000):
        got = 0
        examined = 0
        for i, item in enumerate(iterable):
            examined += 1
            if examined >= max_examined:  # safety valve: pathological dup sources
                print(f"  [{label}] safety stop after {examined} examined items", flush=True)
                break
            raw = item["text"] if isinstance(item, dict) else str(item)
            t = clean(raw)
            if t is None:
                continue
            h = hashlib.md5(t.encode("utf-8", "ignore")).hexdigest()
            if h in SEEN:
                continue
            if self.used + len(t) > budget_chars:
                continue
            SEEN.add(h)
            self.docs.append(t)
            self.used += len(t)
            got += 1
            if got % log_every == 0:
                print(f"  [{label}] {got} docs, {self.used/1e6:.1f}M chars", flush=True)
            if self.used >= budget_chars * 0.995:  # close enough to budget - stop
                break
        self.stats[label] = (got, self.used)
        print(f"[{label}] DONE: {got} docs, {self.used/1e6:.1f}M chars "
              f"(~{self.used/1e6:.0f}M byte-tokens)", flush=True)


def tiny_demo_text(target_chars: int):
    """Fabricate a small mixed corpus so the pipeline can be tested offline."""
    rng = random.Random(7)
    subjects = ["raju", "meera", "the old baker", "a stray cat", "vijay", "the cricket team"]
    verbs = ["found", "built", "lost", "shared", "carried", "fixed"]
    objects = ["a red umbrella", "two mangoes", "an old radio", "a paper boat", "a silver coin"]
    lessons = ["small steps matter", "kindness returns", "patience wins", "friends help"]
    n_doc = 0
    while True:
        n_doc += 1
        sents = [f"{rng.choice(subjects).capitalize()} {rng.choice(verbs)} "
                 f"{rng.choice(objects)} near the old market."
                 for _ in range(rng.randint(4, 9))]
        sents.append(f"They all learned that {rng.choice(lessons)}. (story {n_doc})")
        yield "\n".join(sents)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wiki_simple_m", type=float, default=200, help="Simple-English wiki budget (M byte-tokens)")
    ap.add_argument("--stories_m", type=float, default=100, help="TinyStories budget (M byte-tokens)")
    ap.add_argument("--wiki_en_m", type=float, default=150, help="English wiki budget (M byte-tokens)")
    ap.add_argument("--hinglish_file", type=str, default=None, help="Local txt file (e.g. L3Cube HingCorpus)")
    ap.add_argument("--hinglish_m", type=float, default=50, help="Hinglish file budget (M byte-tokens)")
    ap.add_argument("--out", type=str, default="pretrain_text.txt")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--tiny_demo", action="store_true", help="Offline pipeline test with fake text")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    corpus = Corpus()

    if args.tiny_demo:
        total_budget = int((args.wiki_simple_m + args.stories_m + args.wiki_en_m) * 1e6)
        print("TINY DEMO MODE - no downloads, small fake corpus")
        corpus.harvest(itertools.islice(tiny_demo_text(10**9), 10**9),
                       min(total_budget, 2_000_000), "demo", log_every=500)
    else:
        from datasets import load_dataset  # pip install datasets

        # 1) Simple English Wikipedia - knowledge in easy English
        if args.wiki_simple_m > 0:
            print("Downloading Simple English Wikipedia (streaming)...", flush=True)
            ds = load_dataset("wikimedia/wikipedia", "20231101.simple", split="train", streaming=True)
            corpus.harvest(ds, int(args.wiki_simple_m * 1e6), "wiki_simple")

        # 2) TinyStories - simple coherent narratives
        if args.stories_m > 0:
            print("Downloading TinyStories (streaming)...", flush=True)
            ds = load_dataset("roneneldan/TinyStories", split="train", streaming=True)
            corpus.harvest(ds, int(args.stories_m * 1e6), "stories")

        # 3) English Wikipedia subset - deeper knowledge
        if args.wiki_en_m > 0:
            print("Downloading English Wikipedia subset (streaming)...", flush=True)
            ds = load_dataset("wikimedia/wikipedia", "20231101.en", split="train", streaming=True)
            corpus.harvest(ds, int(args.wiki_en_m * 1e6), "wiki_en")

        # 4) Optional local Hinglish corpus (e.g. L3Cube HingCorpus)
        if args.hinglish_file and os.path.exists(args.hinglish_file):
            print(f"Reading local Hinglish file: {args.hinglish_file}", flush=True)
            with open(args.hinglish_file, encoding="utf-8", errors="ignore") as f:
                def line_iter():
                    for ln in f:
                        yield {"text": ln}
                corpus.harvest(line_iter(), int(args.hinglish_m * 1e6), "hinglish", log_every=2000)
        elif args.hinglish_file:
            print(f"WARNING: {args.hinglish_file} not found, skipping Hinglish part")

    # Shuffle docs (removes source-order bias) and write
    rng.shuffle(corpus.docs)
    print("Shuffling done. Writing output...", flush=True)
    total = 0
    with open(args.out, "w", encoding="utf-8") as f:
        for i, d in enumerate(corpus.docs):
            f.write(d)
            f.write("\n\n")  # document separator
            total += len(d.encode("utf-8")) + 2

    size_mb = os.path.getsize(args.out) / 1e6
    print(f"\n{'='*50}\nDONE: {args.out}")
    print(f"Docs: {len(corpus.docs)}, size: {size_mb:.1f}MB, ~byte-tokens: {total/1e6:.0f}M")
    print("Per-source:", {k: (f"{g} docs", f"{c/1e6:.0f}M chars") for k, (g, c) in corpus.stats.items()})
    print("Next step:")
    print(f"  python train.py --lm_text {args.out} --epochs 1 --lr 3e-4 "
          f"--seq_len 1024 --batch_size 16 --grad_accum 2 --checkpoint_dir checkpoints_pretrain")


if __name__ == "__main__":
    import itertools
    main()
