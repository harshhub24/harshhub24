# ECHO GPT-2 — Kaggle Start Pack 🚀

GPT-2 small (124M) ko 2-stage fine-tune karke Hinglish friend bot **Echo** banane ka poora kit.
Purana 50M wala plan ab band — ye GPT-2 route final hai.

## Is zip me kya hai

| File | Kaam |
|---|---|
| `echo_kaggle_gpt2.ipynb` | **Main notebook** — Kaggle pe yehi chalana hai (7 cells) |
| `echo_gpt2/hinglish_pretrain.py` | Stage 1 — Hinglish pretraining (+English replay) |
| `echo_gpt2/sft_finetune.py` | Stage 2 — Echo persona SFT (6,362 pairs) |
| `echo_gpt2/chat.py` | Chat interface — Kaggle + laptop dono pe |
| `echo_gpt2/requirements.txt` | Dependencies |
| `echo_training_data/sft_final.json` | Stage 2 ka data (6,362 chat pairs) |
| `echo_training_data/persona_anchors.json` | Echo identity anchors |
| `echo_training_data/hinglish_4900.json` | Extra Hinglish pairs |
| `echo_training_data/topic_pack.json` | Topic coverage pack |

---

## STEP 0 — Account ready (one-time)

1. [kaggle.com](https://www.kaggle.com) pe account banao (13+ allowed, 15 age theek hai)
2. **Settings → Phone section → Verify** — ghar walon ke number se bhi chalega.
   GPU use karne ke liye phone verification ZAROORI hai. Iske bina GPU quota nahi milega.

## STEP 1 — 2 datasets upload karo (one-time)

**Dataset A — tumhara kit:**
1. Kaggle pe **Create → New Dataset** (ya kisi notebook ke right panel → Input → Upload)
2. `echo_kaggle_final.zip` upload karo
3. Naam: `echo-kit` → **Private** hi rakhna → Create
4. Kaggle zip ko khud unzip kar deta hai, tension mat lena

**Dataset B — L3Cube corpus:**
1. Fir se **Create → New Dataset**
2. Tumhari **full HingCorpus file (2.49GB)** upload karo — jo bhi naam se hai (`.txt` hi hona chahiye; agar upload slow lage to pehle zip kar lena, Kaggle khud unzip kar deta hai)
3. Naam: `l3cube-hinglish` → Private → Create
4. CELL 4 dataset me se **sabse badi .txt** khud pakad lega — chhota sample (7.4MB wala `train.txt`) ho to bhi chalega, script word-tag format bhi khud handle karta hai

> Privacy rule: dono datasets **Private** rehne do. Kisi ko link mat do.

## STEP 2 — Notebook banao

1. **Create → New Notebook**
2. **File → Import Notebook** → apne laptop se `echo_kaggle_gpt2.ipynb` select karo
3. Right panel **Session options**:
   - **Accelerator → GPU T4 x2** (ya P100)
   - **Internet → ON** (GPT-2 weights + datasets download honge — bina iske kuch nahi chalega)
4. Right panel **Input → Add Input** → dono datasets add karo:
   - `echo-kit` (tumhara)
   - `l3cube-hinglish` (train.txt wala)

## STEP 3 — Cells chalao (upar se neeche)

| Cell | Kya hoga | Time |
|---|---|---|
| CELL 1 | GPU check + pip install | 1-2 min |
| CELL 2 | Kit files ready + check | 10 sec |
| CELL 3 | Data sanity (6,362 pairs dikhega) | 5 sec |
| CELL 4 | **Stage 1** — Hinglish pretraining | ~30-50 min |
| CELL 5 | **Stage 2** — Echo persona SFT | ~15-30 min |
| CELL 6 | 7 chat probes — quality test | 2-3 min |
| CELL 7 | Final zip banega | 1 min |

**Healthy loss signals:**
- Stage 1: ~2.7 se start → ~2.0-2.3 pe settle
- Stage 2: ~2.5 se start → ~1.0-1.4 pe settle
- CELL 4 me pehli line ye dikhega: `Hinglish corpus: /kaggle/input/l3cube-hinglish/<file>.txt (2.49 GB)` — matlab full corpus pakda gaya ✅
- Stage 1 full corpus ke saath 50M chars use karega (~18M tokens) — Twitter noise (URLs/@mentions) script khud saaf karta hai

**Important — quota bachao:**
- Total run ~1.5-2 hours. 30h/week quota hai, tension nahi.
- Beech me Internet OFF mat karna, notebook close mat karna.
- Session toote (disconnect) to: notebook kholo → wahi cell jahan ruka tha dobara run karo.
  Stage 1 resume-safe hai (same command chalao, wahi checkpoint continue hoga).

## STEP 4 — Save Version (MODEL YAHIN BACHEGA!)

Kaggle pe `/kaggle/working` ke files sirf **Save Version** karne pe hi bache rehte hain:

1. Right top **Save Version** button → **Quick Save** → Save
2. Save hone ke baad version kholo → **Output** section → `echo_gpt2_final.zip` download karo
3. Ye zip = tumhara final Echo model (laptop pe chat isi se chalega)

## STEP 5 — Laptop pe chat (CPU chalega, GPU nahi chahiye)

`echo_gpt2_final.zip` extract karo (usme `echo_gpt2_sft` jaisa folder hoga), fir:

```
pip install torch transformers
python chat.py --model_dir echo_gpt2_sft --device cpu --int8
```

- Tumhare i3 + GT 610 pe bhi chalega (int8 quantization, ~500MB → ~150MB model)
- Har jawab 5-15 sec me aayega — normal hai CPU pe

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `GPU nahi hai` aaya CELL 1 me | Session options → Accelerator → GPU T4 x2 select karo, notebook re-run |
| Phone verification ke bina GPU option disabled | Settings → Phone verify karo (ghar walon ke number se) |
| CELL 2 me `FILES READY` nahi aaya | Dono datasets attach hue? Input panel check karo. Zip me `echo_gpt2/` folder hai na? |
| CELL 4 me `Koi txt nahi mili` aaya | `l3cube-hinglish` dataset attach nahi hai — Add Input se add karo |
| `CUDA out of memory` | CELL 4/5 me `--batch_size 4` kar do aur `--grad_accum 4` kar do |
| Quota khatam message | "You have used your weekly GPU quota" — agle week automatically reset hoga |
| CELL 6 output word salad jaisa | Panic mat karo — output chat me paste karo, fix bataunga (epochs/sampling adjust) |

## Iske baad kya (roadmap)

1. **CELL 6 ka output chat me paste karo** → quality verdict milega
2. Model ready hone ke baad: memory system → websearch RAG → `/sikha` chat-learning → future v2/v3 fine-tunes
3. Purana 50M model ka kaam ab optional hai — GPT-2 hi main model hai
