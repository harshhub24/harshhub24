"""
ECHO-GPT2 Stage 1: Hinglish continued pretraining (+ English replay buffer).

Takes GPT-2 small (124M, English-pretrained) and adapts it to Hinglish by
continued LM training. Adds ~15-20% English TinyStories as a REPLAY buffer so
the model does NOT forget English (catastrophic forgetting protection).

Corpus sources (tried in order, first that works is used):
  - --hf_hinglish DSMJ910/hinglish-instruct-10k  (accessible, chat-style)
  - --hf_hinglish l3cube-pune/hing-corpus  (may 404; L3Cube hosts on GitHub)
  - --hinglish_file /path/to/hinglish.txt  (local file, e.g. L3Cube GitHub download)

Usage (Kaggle):
    !pip -q install transformers datasets accelerate
    python hinglish_pretrain.py \
        --hinglish_chars 30_000_000 \
        --english_replay_chars 6_000_000 \
        --epochs 1 --lr 5e-5 --seq_len 1024 \
        --batch_size 8 --grad_accum 2 \
        --out_dir /kaggle/working/echo_gpt2_hinglish
"""
import argparse
import hashlib
import os
import random
import re
import sys

import torch
from torch.utils.data import Dataset, DataLoader
from torch.cuda.amp import autocast, GradScaler
from transformers import GPT2Tokenizer, GPT2LMHeadModel, get_cosine_schedule_with_warmup

SEEN = set()


def clean(t):
    """Basic cleanup: strip URLs, @mentions, # symbols (Twitter noise from L3Cube)."""
    t = (t or "").strip()
    t = re.sub(r"https?://\S+", "", t)      # URLs
    t = re.sub(r"@\w+", "", t)              # @mentions
    t = re.sub(r"#(\w+)", r"\1", t)         # keep hashtag word, drop #
    t = re.sub(r"\s{2,}", " ", t)           # collapse spaces
    if len(t) < 20:
        return None
    return t


def harvest_hf(hf_name, split, text_field, budget_chars, max_items=2_000_000):
    """Stream a HF dataset, harvest clean text up to budget_chars."""
    from datasets import load_dataset
    out, used = [], 0
    try:
        ds = load_dataset(hf_name, split=split, streaming=True, trust_remote_code=True)
    except Exception as e:
        print(f"  [WARN] could not load {hf_name}: {e}")
        return out
    for i, item in enumerate(ds):
        if i >= max_items:
            break
        raw = item.get(text_field, "") if isinstance(item, dict) else str(item)
        t = clean(raw)
        if not t:
            continue
        h = hashlib.md5(t.encode("utf-8", "ignore")).hexdigest()
        if h in SEEN:
            continue
        if used + len(t) > budget_chars:
            break
        SEEN.add(h)
        out.append(t)
        used += len(t)
        if len(out) % 2000 == 0:
            print(f"  [{hf_name}] {len(out)} docs, {used/1e6:.1f}M chars", flush=True)
    print(f"[{hf_name}] DONE: {len(out)} docs, {used/1e6:.1f}M chars")
    return out


_WORDTAG_RE = re.compile(r"^[^\t]+\t[A-Z]{1,4}\s*$")
_TAG_SUFFIX_RE = re.compile(r"\t[A-Z]{1,4}\s*$")


def _looks_wordtagged(path, sample=300):
    """Detect L3Cube word-level format: 'word<TAB>HI' lines, blank line = sentence end."""
    total, hits = 0, 0
    with open(path, encoding="utf-8", errors="ignore") as f:
        for ln in f:
            s = ln.strip("\r\n").strip()
            if not s:
                continue
            total += 1
            if _WORDTAG_RE.match(s):
                hits += 1
            if total >= sample:
                break
    return total > 0 and hits / total >= 0.8


def harvest_file(path, budget_chars):
    """Harvest text from a local file. Auto-detects the L3Cube word-tag format
    (word<TAB>LANG lines) and reconstructs full sentences from it."""
    if _looks_wordtagged(path):
        print(f"[file:{path}] word-tag format detect hua (word<TAB>HI/EN) -> "
              f"sentences reconstruct kar raha hoon")
        return _harvest_file_wordtag(path, budget_chars)
    out, used = [], 0
    with open(path, encoding="utf-8", errors="ignore") as f:
        for ln in f:
            t = clean(ln)
            if not t:
                continue
            h = hashlib.md5(t.encode("utf-8", "ignore")).hexdigest()
            if h in SEEN:
                continue
            if used + len(t) > budget_chars:
                break
            SEEN.add(h)
            out.append(t)
            used += len(t)
    print(f"[file:{path}] DONE: {len(out)} lines, {used/1e6:.1f}M chars")
    return out


def _harvest_file_wordtag(path, budget_chars):
    """Reconstruct sentences from 'word<TAB>LANG' format; blank line = sentence end."""
    out, used, words = [], 0, []

    def emit():
        nonlocal used
        if not words:
            return True
        t = clean(" ".join(words))
        words.clear()
        if not t:
            return True
        h = hashlib.md5(t.encode("utf-8", "ignore")).hexdigest()
        if h in SEEN:
            return True
        if used + len(t) > budget_chars:
            return False
        SEEN.add(h)
        out.append(t)
        used += len(t)
        return True

    with open(path, encoding="utf-8", errors="ignore") as f:
        for ln in f:
            s = ln.strip("\r\n").strip()
            if not s:
                if not emit():
                    break
                continue
            words.append(_TAG_SUFFIX_RE.sub("", s))
        emit()  # last group at EOF
    print(f"[file:{path}] DONE: {len(out)} sentences (reconstructed), {used/1e6:.1f}M chars")
    return out


class PackedDataset(Dataset):
    """Tokenize texts, pack into fixed-length seq chunks separated by EOS."""

    def __init__(self, texts, tokenizer, seq_len):
        eos = tokenizer.eos_token_id
        ids = []
        for t in texts:
            ids.extend(tokenizer.encode(t, add_special_tokens=False) + [eos])
        n = len(ids) // seq_len
        self.chunks = [ids[i * seq_len:(i + 1) * seq_len] for i in range(n)]
        print(f"Packed: {len(ids)} tokens -> {n} sequences of {seq_len}")

    def __len__(self):
        return len(self.chunks)

    def __getitem__(self, i):
        x = torch.tensor(self.chunks[i], dtype=torch.long)
        return x, x.clone()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hf_hinglish", default="DSMJ910/hinglish-instruct-10k",
                    help="HF dataset name (try l3cube-pune/hing-corpus as alternative)")
    ap.add_argument("--hf_split", default="train")
    ap.add_argument("--hf_text_field", default="text",
                    help="Field containing text (try 'instruction'/'response'/'output')")
    ap.add_argument("--hinglish_file", default=None,
                    help="Local Hinglish txt (overrides HF, e.g. L3Cube GitHub download)")
    ap.add_argument("--hinglish_chars", type=int, default=30_000_000)
    ap.add_argument("--english_replay_chars", type=int, default=6_000_000)
    ap.add_argument("--hf_english", default="roneneldan/TinyStories")
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--lr", type=float, default=5e-5)
    ap.add_argument("--seq_len", type=int, default=1024)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--grad_accum", type=int, default=2)
    ap.add_argument("--warmup_steps", type=int, default=100)
    ap.add_argument("--save_every", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    print("Loading GPT-2 small + tokenizer...")
    tok = GPT2Tokenizer.from_pretrained("gpt2")
    tok.pad_token = tok.eos_token
    model = GPT2LMHeadModel.from_pretrained("gpt2").to(device)
    print(f"Params: {sum(p.numel() for p in model.parameters())/1e6:.1f}M")

    # ---- Harvest Hinglish (COMBINE all sources that work) ----
    # Order: user override file -> user HF dataset -> instruct (clean chat-style)
    # -> L3Cube (bulk real Hinglish). Dedup via SEEN, global char cap.
    print("\n=== Harvesting Hinglish (all available sources combined) ===")
    hinglish = []
    total_chars = 0

    def add(got):
        nonlocal total_chars
        hinglish.extend(got)
        total_chars += sum(len(t) for t in got)
        print(f"  [total so far] {len(hinglish)} docs, {total_chars/1e6:.1f}M chars")

    if args.hinglish_file and os.path.exists(args.hinglish_file):
        add(harvest_file(args.hinglish_file, args.hinglish_chars))

    candidates = [
        (args.hf_hinglish, args.hf_split, args.hf_text_field),
        ("DSMJ910/hinglish-instruct-10k", "train", "instruction"),
        ("DSMJ910/hinglish-instruct-10k", "train", "output"),
        ("DSMJ910/hinglish-instruct-10k", "train", "response"),
        ("DSMJ910/hinglish-instruct-10k", "train", "text"),
        ("l3cube-pune/hing-corpus", "train", "text"),
    ]
    seen_combos = set()
    for name, split, field in candidates:
        if total_chars >= args.hinglish_chars:
            break
        key = (name, field)
        if key in seen_combos:
            continue
        seen_combos.add(key)
        print(f"  Trying {name} (field={field})...")
        remaining = args.hinglish_chars - total_chars
        got = harvest_hf(name, split, field, remaining)
        if got:
            add(got)
    if not hinglish:
        print("\n!! No Hinglish source worked.")
        print("   Options:")
        print("   1. Download L3Cube-HingCorpus from https://github.com/l3cube-pune/code-mixed-nlp")
        print("      and pass --hinglish_file /path/to/hinglish.txt")
        print("   2. Set --hf_hinglish <other-dataset> --hf_text_field <field-name>")
        sys.exit(1)

    # ---- English replay (forgetting protection) ----
    # Auto-balance: Hinglish chhota ho to English replay bhi chhota (~15-20% tokens).
    # Full corpus ke saath requested value hi use hogi (cap us se bada hoga).
    replay_budget = min(args.english_replay_chars, int(0.35 * max(total_chars, 1)))
    print(f"\n=== English replay: {replay_budget/1e6:.1f}M chars "
          f"(Hinglish {total_chars/1e6:.1f}M ke saath balanced) ===")
    english = harvest_hf(args.hf_english, "train", "text", replay_budget)
    if not english:
        print("  [WARN] English replay empty — proceeding without (forgetting risk slightly higher)")

    rng = random.Random(args.seed)
    all_texts = hinglish + english
    rng.shuffle(all_texts)
    print(f"\nTotal docs: {len(all_texts)} (Hinglish {len(hinglish)} + English {len(english)})")

    # ---- Tokenize + pack ----
    print("\nTokenizing + packing (may take a minute)...")
    ds = PackedDataset(all_texts, tok, args.seq_len)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, drop_last=True,
                        num_workers=2, pin_memory=True)

    # ---- Optimizer + scheduler ----
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.1, betas=(0.9, 0.95))
    total_steps = max(1, (len(loader) // args.grad_accum) * args.epochs)
    sched = get_cosine_schedule_with_warmup(opt, args.warmup_steps, total_steps)
    scaler = GradScaler(enabled=(device.type == "cuda"))

    os.makedirs(args.out_dir, exist_ok=True)
    print(f"\nTotal optimizer steps: {total_steps}")
    print(f"Saving to: {args.out_dir}")

    model.train()
    global_step = 0
    for epoch in range(args.epochs):
        opt.zero_grad(set_to_none=True)
        for i, (x, y) in enumerate(loader):
            x, y = x.to(device), y.to(device)
            with autocast(enabled=(device.type == "cuda")):
                out = model(input_ids=x, labels=y)
                loss = out.loss / args.grad_accum
            scaler.scale(loss).backward()
            if (i + 1) % args.grad_accum == 0:
                scaler.unscale_(opt)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(opt)
                scaler.update()
                opt.zero_grad(set_to_none=True)
                sched.step()
                global_step += 1
                if global_step % 25 == 0:
                    lr_now = sched.get_last_lr()[0]
                    print(f"  epoch {epoch} step {global_step}/{total_steps} "
                          f"loss {out.loss.item():.4f} lr {lr_now:.2e}", flush=True)
                if args.save_every and global_step % args.save_every == 0:
                    model.save_pretrained(args.out_dir)
                    tok.save_pretrained(args.out_dir)
                    print(f"  -> saved checkpoint at step {global_step}")

    model.save_pretrained(args.out_dir)
    tok.save_pretrained(args.out_dir)
    print(f"\nDONE. Hinglish-adapted checkpoint: {args.out_dir}")
    print(f"Next: python sft_finetune.py --init_from {args.out_dir} "
          f"--data <sft_final.json> --out_dir <sft_dir>")


if __name__ == "__main__":
    main()
