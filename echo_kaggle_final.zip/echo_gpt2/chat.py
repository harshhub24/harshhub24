"""
ECHO-GPT2 Chat: load SFT checkpoint, generate response with sampling.

Interface mirrors the 50M echo_fixed/chat.py for ecosystem compatibility
(memory, websearch, /sikha learning can plug in unchanged).

Usage (CLI):
    python chat.py --model_dir /path/to/sft_checkpoint --device cuda
    python chat.py --model_dir /path/to/sft_checkpoint --device cpu --int8  # local PC

Usage (module):
    from chat import load_model, generate_response
    model, tok = load_model("/path/to/sft_checkpoint", device="cuda")
    out = generate_response(model, tok, "Kaise ho bhai", device="cuda")
"""
import argparse
import torch
from transformers import GPT2Tokenizer, GPT2LMHeadModel


def load_model(model_dir, device="cuda", int8=False):
    """Load SFT checkpoint. int8=True quantizes for CPU inference (smaller + faster)."""
    dev = torch.device(device if (device == "cpu" or torch.cuda.is_available()) else "cpu")
    tok = GPT2Tokenizer.from_pretrained(model_dir)
    tok.pad_token = tok.eos_token
    if int8:
        # Dynamic int8 quantization — works on CPU, ~2x faster + ~50% smaller
        from torch.quantization import quantize_dynamic
        model = GPT2LMHeadModel.from_pretrained(model_dir)
        model = quantize_dynamic(model, {torch.nn.Linear}, dtype=torch.qint8)
        model.to(dev)
    else:
        model = GPT2LMHeadModel.from_pretrained(model_dir).to(dev)
    model.eval()
    if dev.type == "cuda":
        try:
            model = model.half()  # fp16 inference on GPU — faster, no quality drop for chat
        except Exception:
            pass
    return model, tok


@torch.no_grad()
def generate_response(model, tok, prompt, max_new_tokens=150, temperature=0.8,
                      top_k=50, top_p=0.9, repetition_penalty=1.15, device="cuda"):
    """Generate Echo's response to a user prompt."""
    dev = next(model.parameters()).device
    inp = f"User: {prompt}\nResponse: "
    ids = tok.encode(inp, add_special_tokens=False)
    in_ids = torch.tensor([ids], dtype=torch.long, device=dev)
    attn = torch.ones_like(in_ids)
    out = model.generate(
        input_ids=in_ids,
        attention_mask=attn,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        temperature=temperature,
        top_k=top_k,
        top_p=top_p,
        repetition_penalty=repetition_penalty,
        eos_token_id=tok.eos_token_id,
        pad_token_id=tok.eos_token_id,
    )
    gen = out[0][len(ids):].tolist()
    if tok.eos_token_id in gen:
        gen = gen[:gen.index(tok.eos_token_id)]
    text = tok.decode(gen, skip_special_tokens=True).strip()
    return text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_dir", required=True)
    ap.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    ap.add_argument("--int8", action="store_true",
                    help="int8 quantization (CPU inference — recommended for local PC)")
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--max_new_tokens", type=int, default=150)
    args = ap.parse_args()

    model, tok = load_model(args.model_dir, device=args.device, int8=args.int8)
    print(f"ECHO-GPT2 ready ({'int8' if args.int8 else 'full precision'}, "
          f"device={args.device}). Type 'quit' to exit.")
    while True:
        try:
            p = input("\nYOU: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not p or p.lower() in ("quit", "exit"):
            break
        r = generate_response(model, tok, p,
                              max_new_tokens=args.max_new_tokens,
                              temperature=args.temperature,
                              device=args.device)
        print("ECHO:", r)


if __name__ == "__main__":
    main()
