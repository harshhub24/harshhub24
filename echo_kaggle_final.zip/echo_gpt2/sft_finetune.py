"""
ECHO-GPT2 Stage 2: SFT on sft_final.json (with --init_from Stage 1 Hinglish checkpoint).

Template: "User: {prompt}\nResponse: {response}<eos>"
Prompt tokens are masked with -100 (model only learns to predict its own response).

Usage:
    python sft_finetune.py \
        --init_from /kaggle/working/echo_gpt2_hinglish \
        --data /kaggle/working/echo_training_data/sft_final.json \
        --out_dir /kaggle/working/echo_gpt2_sft \
        --epochs 3 --lr 1e-4 --seq_len 1024 --batch_size 8 --grad_accum 2

Skip Stage 1 (use vanilla GPT-2 directly):
    python sft_finetune.py --init_from gpt2 --data ... --out_dir ...
"""
import argparse
import json
import os
import random

import torch
from torch.utils.data import Dataset, DataLoader
from torch.cuda.amp import autocast, GradScaler
from transformers import GPT2Tokenizer, GPT2LMHeadModel, get_cosine_schedule_with_warmup


class SFTDataset(Dataset):
    """Each example: 'User: {prompt}\\nResponse: {response}<eos>'
    Labels for the prompt portion are -100 (ignored by loss)."""

    def __init__(self, pairs, tokenizer, seq_len):
        self.tok = tokenizer
        self.seq_len = seq_len
        self.pairs = pairs
        self.eos = tokenizer.eos_token_id

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, i):
        p, r = self.pairs[i]["prompt"], self.pairs[i]["response"]
        prompt_str = f"User: {p}\nResponse: "
        prompt_ids = self.tok.encode(prompt_str, add_special_tokens=False)
        resp_ids = self.tok.encode(r, add_special_tokens=False) + [self.eos]
        # Left-truncate prompt if total exceeds seq_len (keep response intact)
        if len(prompt_ids) + len(resp_ids) > self.seq_len:
            overflow = (len(prompt_ids) + len(resp_ids)) - self.seq_len
            cut = min(overflow, len(prompt_ids))
            prompt_ids = prompt_ids[cut:]
            if len(prompt_ids) + len(resp_ids) > self.seq_len:
                resp_ids = resp_ids[:self.seq_len - len(prompt_ids)]
        ids = prompt_ids + resp_ids
        labels = [-100] * len(prompt_ids) + resp_ids[:]
        return ids, labels


def collate(batch, pad_id):
    maxlen = max(len(x[0]) for x in batch)
    input_ids, labels, attn = [], [], []
    for ids, lbls in batch:
        pad = maxlen - len(ids)
        input_ids.append(ids + [pad_id] * pad)
        labels.append(lbls + [-100] * pad)
        attn.append([1] * len(ids) + [0] * pad)
    return (torch.tensor(input_ids, dtype=torch.long),
            torch.tensor(labels, dtype=torch.long),
            torch.tensor(attn, dtype=torch.long))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--init_from", default="gpt2",
                    help="Stage 1 checkpoint dir OR 'gpt2' to skip Stage 1")
    ap.add_argument("--data", nargs="+", required=True,
                    help="One or more sft_*.json files")
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--seq_len", type=int, default=1024)
    ap.add_argument("--batch_size", type=int, default=8)
    ap.add_argument("--grad_accum", type=int, default=2)
    ap.add_argument("--warmup_steps", type=int, default=50)
    ap.add_argument("--save_every", type=int, default=200)
    ap.add_argument("--max_samples", type=int, default=None)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    print(f"Loading model from: {args.init_from}")
    tok = GPT2Tokenizer.from_pretrained(args.init_from)
    tok.pad_token = tok.eos_token
    model = GPT2LMHeadModel.from_pretrained(args.init_from).to(device)
    print(f"Params: {sum(p.numel() for p in model.parameters())/1e6:.1f}M")

    # ---- Load SFT data ----
    pairs = []
    for path in args.data:
        with open(path) as f:
            d = json.load(f)
        before = len(d)
        # GPT-2 BPE: ~3 chars/token for Hinglish, so 1024 tokens ~ 3072 chars
        d = [x for x in d
             if len(x["prompt"].encode()) + len(x["response"].encode()) < args.seq_len * 3]
        print(f"  {os.path.basename(path)}: {before} -> {len(d)} pairs (after seq_len filter)")
        pairs.extend(d)
    if args.max_samples:
        pairs = pairs[:args.max_samples]
    random.shuffle(pairs)
    print(f"Total SFT pairs: {len(pairs)}")

    ds = SFTDataset(pairs, tok, args.seq_len)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=True, drop_last=True,
                        collate_fn=lambda b: collate(b, tok.eos_token_id),
                        num_workers=2, pin_memory=True)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.1, betas=(0.9, 0.95))
    total_steps = max(1, (len(loader) // args.grad_accum) * args.epochs)
    sched = get_cosine_schedule_with_warmup(opt, args.warmup_steps, total_steps)
    scaler = GradScaler(enabled=(device.type == "cuda"))

    os.makedirs(args.out_dir, exist_ok=True)
    print(f"\nTotal optimizer steps: {total_steps}")
    print(f"Saving to: {args.out_dir}")

    model.train()
    global_step = 0
    for epoch in range(args.epochs):
        opt.zero_grad(set_to_none=True)
        ep_loss, nb = 0.0, 0
        for i, (input_ids, labels, attn) in enumerate(loader):
            input_ids = input_ids.to(device)
            labels = labels.to(device)
            attn = attn.to(device)
            with autocast(enabled=(device.type == "cuda")):
                out = model(input_ids=input_ids, attention_mask=attn, labels=labels)
                loss = out.loss / args.grad_accum
            scaler.scale(loss).backward()
            if (i + 1) % args.grad_accum == 0:
                scaler.unscale_(opt)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(opt)
                scaler.update()
                opt.zero_grad(set_to_none=True)
                sched.step()
                global_step += 1
                ep_loss += out.loss.item()
                nb += 1
                if global_step % 25 == 0:
                    print(f"  epoch {epoch} step {global_step}/{total_steps} "
                          f"loss {out.loss.item():.4f} lr {sched.get_last_lr()[0]:.2e}",
                          flush=True)
                if args.save_every and global_step % args.save_every == 0:
                    model.save_pretrained(args.out_dir)
                    tok.save_pretrained(args.out_dir)
                    print(f"  -> saved checkpoint at step {global_step}")
        print(f"== epoch {epoch} done, avg loss {ep_loss/max(1,nb):.4f} ==")

    model.save_pretrained(args.out_dir)
    tok.save_pretrained(args.out_dir)
    print(f"\nDONE. SFT checkpoint: {args.out_dir}")
    print(f"Next: python chat.py --model_dir {args.out_dir}")


if __name__ == "__main__":
    main()
